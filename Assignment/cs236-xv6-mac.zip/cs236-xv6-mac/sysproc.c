#include "types.h"
#include "x86.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"


// int sys_custom_fork(void) {
//     int start_later, exec_time;
//     if (argint(0, &start_later) < 0 || argint(1, &exec_time) < 0)
//         return -1;
//     return sys_custom_fork(start_later, exec_time);
// }

// int sys_scheduler_start(void) {
//     return sys_scheduler_start();
// }


// in sysproc.c
// int sys_signal(void) {
//     int handler;
//     if(argint(0, &handler) < 0)
//         return -1;

//     myproc()->signal_handler = (void*)handler;
//     return 0;
// }

int sys_signal(void) {
    void (*handler)(void);
    
    if (argptr(0, (void*)&handler, sizeof(void*)) < 0)
        return -1;

    myproc()->signal_handler = handler;
    return 0;
}

 
int
sys_fork(void)
{
  return fork();
}

int
sys_exit(void)
{
  exit();
  return 0;  // not reached
}

int
sys_wait(void)
{
  return wait();
}

int
sys_kill(void)
{
  int pid;

  if(argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

int
sys_getpid(void)
{
  return myproc()->pid;
}

int
sys_sbrk(void)
{
  int addr;
  int n;

  if(argint(0, &n) < 0)
    return -1;
  addr = myproc()->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

int
sys_sleep(void)
{
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(myproc()->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

// return how many clock tick interrupts have occurred
// since start.
int
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}
